var quList = [
	{
		question: 'What is My Name?',
		options: {
			'0': 'Shahnawaz',
			'1': 'Brian',
			'2': 'Filza',
			'3': 'Husain',
			'4': 'Indian'
		}
		images: {
			'0': 
			'1':
			'2':
			'3':
			'4':
		}
	},
	{
		question: 'What is My Address?',
		options: {
			'0': 'India',
			'1': 'Austrelia',
			'2': 'Srilanka',
			'3': 'Goa'
		}
	},
	{
		question: 'What is My Age?',
		options: {
			'0': '15',
			'1': '26',
			'2': '34',
			'3': '51',
			'4': '68',
			'5': '509'
		}
	},
	{
		question: 'What is My Gender?',
		options: {
			'0': 'Female',
			'1': 'Male',
			'2': 'Trans',
			'3': 'Undefined',
			'4': 'Complicated',
			'5': 'IDK'
		}
	},
	{
		question: 'What is My Surname?',
		options: {
			'0': 'Hassan',
			'1': 'Roy',
			'2': 'Bose',
			'3': 'Mandal',
			'4': 'Sharma',
			'5': 'Rajput'
		}
	},
	{
		question: 'What is My Pet?',
		options: {
			'0': 'Dog',
			'1': 'Cat',
			'2': 'Goat',
			'3': 'Tiger',
			'4': 'Belly',
			'5': 'Antelope'
		}
	},
	{
		question: 'What is My Weight?',
		options: {
			'0': '38',
			'1': '49',
			'2': '94',
			'3': '50',
			'4': '31',
			'5': '580'
		}
	},
	{
		question: 'What is My Study?',
		options: {
			'0': 'BSc',
			'1': 'BCom',
			'2': 'HS',
			'3': '10',
			'4': 'BTech',
			'5': 'MTech'
		}
	},
	{
		question: 'What is My Planet?',
		options: {
			'0': 'Jupiter',
			'1': 'Earth',
			'2': 'Moon',
			'3': 'Pluto',
			'4': 'Antromorphic',
			'5': 'Mercury'
		}
	},
	{
		question: 'What is My Face Color?',
		options: {
			'0': 'Fair',
			'1': 'Black',
			'2': 'Dark',
			'3': 'Blue',
			'4': 'Green',
			'5': 'Purple'
		}
	}
]